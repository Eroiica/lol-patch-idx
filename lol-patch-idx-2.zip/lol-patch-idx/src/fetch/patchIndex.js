// ═══════════════════════════════════════════════════════════════
// Patch Index — URL resolution and discovery
//
// Discovers patch note URLs from the Riot patch notes index page.
// Tag filter: 'GAME UPDATES' => Patch Page
// ═══════════════════════════════════════════════════════════════

const BASE = "https://www.leagueoflegends.com";
const INDEX_URL = `${BASE}/en-us/news/tags/patch-notes/`;
const GAME_UPDATES_URL = `${BASE}/en-us/news/game-updates/`;

// Known URL patterns — some patches have "league-of-legends-" prefix
const KNOWN_PATCHES = {
  "26.5": "league-of-legends-patch-26-5-notes",
  "26.4": "league-of-legends-patch-26-4-notes",
  "26.3": "patch-26-3-notes",
  "26.2": "patch-26-2-notes",
  "26.1": "patch-26-1-notes",
  "25.24": "patch-25-24-notes",
  "25.23": "patch-25-23-notes",
  "25.22": "patch-25-22-notes",
  "25.21": "patch-25-21-notes",
  "25.20": "patch-25-20-notes",
  "25.19": "patch-25-19-notes",
  "25.18": "patch-25-18-notes",
};

function patchUrl(patchId) {
  const slug = KNOWN_PATCHES[patchId];
  if (slug) return `${BASE}/en-us/news/game-updates/${slug}/`;
  // Fallback: construct from patchId
  const [major, minor] = patchId.split(".");
  return `${BASE}/en-us/news/game-updates/patch-${major}-${minor}-notes/`;
}

function allPatchUrls() {
  return Object.entries(KNOWN_PATCHES).map(([id, slug]) => ({
    patch: id,
    url: `${BASE}/en-us/news/game-updates/${slug}/`,
    slug,
  }));
}

// Parse patch list entries from index page markdown
function parseIndexPage(markdown) {
  const entries = [];
  const re = /Game Updates\s+(\d{4}-\d{2}-\d{2})T[\d:]+\.\d+Z\s+(.+?Notes)\s+(.+?)(?=\]\(|\n\[|$)/g;
  let m;
  while ((m = re.exec(markdown)) !== null) {
    const title = m[2].trim();
    const patchMatch = title.match(/(\d+\.\d+)/);
    if (patchMatch) {
      entries.push({
        patch: patchMatch[1],
        date: m[1],
        title,
        blurb: m[3].trim(),
      });
    }
  }
  return entries;
}

module.exports = { patchUrl, allPatchUrls, parseIndexPage, KNOWN_PATCHES, INDEX_URL, GAME_UPDATES_URL };
