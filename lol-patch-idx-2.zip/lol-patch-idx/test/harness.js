#!/usr/bin/env node
// Test harness — parses all .md fixtures in test/fixtures/live/ and reports results
const fs = require("fs");
const path = require("path");
const { parseMarkdown } = require("../cli/parsePatch");

const dir = path.join(__dirname, "fixtures", "live");
const files = fs.readdirSync(dir).filter(f => f.endsWith(".md")).sort();

console.log(`\n${"═".repeat(80)}`);
console.log(`  LOL PATCH IDX — Multi-Patch Test Harness`);
console.log(`  ${files.length} patches found in ${dir}`);
console.log(`${"═".repeat(80)}\n`);

const results = [];
let totalChamps = 0, totalItems = 0, totalSystems = 0, totalStats = 0;

for (const file of files) {
  const content = fs.readFileSync(path.join(dir, file), "utf-8");
  const patchId = file.replace(".md", "");
  
  try {
    const { blocks, patchData } = parseMarkdown(content, `https://www.leagueoflegends.com/en-us/news/game-updates/patch-${patchId.replace(".", "-")}-notes/`);
    const stats = patchData.champions.reduce(
      (n, c) => n + c.changes.reduce((m, ch) => m + ch.stats.length, 0), 0
    );
    const buffCount = patchData.champions.filter(c => c.verdict === "BUFF").length;
    const nerfCount = patchData.champions.filter(c => c.verdict === "NERF").length;
    const adjCount = patchData.champions.filter(c => c.verdict === "ADJUSTED").length;
    
    totalChamps += patchData.champions.length;
    totalItems += patchData.items.length;
    totalSystems += patchData.systems.length;
    totalStats += stats;
    
    const row = {
      patch: patchData.patch,
      blocks: blocks.length,
      champs: patchData.champions.length,
      buffs: buffCount,
      nerfs: nerfCount,
      adj: adjCount,
      items: patchData.items.length,
      systems: patchData.systems.length,
      stats,
      ok: patchData.patch !== "unknown" && patchData.champions.length > 0,
    };
    results.push(row);
    
    const status = row.ok ? "✓" : "✗";
    console.log(`${status} Patch ${row.patch.padEnd(6)} | ${String(row.blocks).padStart(4)} blocks | ${String(row.champs).padStart(3)} champs (${row.buffs}B/${row.nerfs}N/${row.adj}A) | ${String(row.items).padStart(2)} items | ${String(row.systems).padStart(3)} sys | ${String(row.stats).padStart(3)} stats`);
    
    // Warn on anomalies
    if (patchData.champions.length === 0) console.log(`  ⚠  No champions found!`);
    if (stats === 0 && patchData.champions.length > 0) console.log(`  ⚠  Champions found but no stat lines parsed`);
    if (patchData.items.length === 0) console.log(`  ⚠  No items found`);
    if (patchData.systems.length === 0) console.log(`  ⚠  No systems found`);
    
  } catch (err) {
    console.log(`✗ Patch ${patchId.padEnd(6)} | ERROR: ${err.message}`);
    results.push({ patch: patchId, ok: false, error: err.message });
  }
}

const passed = results.filter(r => r.ok).length;
const failed = results.filter(r => !r.ok).length;

console.log(`\n${"─".repeat(80)}`);
console.log(`  TOTALS: ${totalChamps} champions, ${totalItems} items, ${totalSystems} systems, ${totalStats} stat changes`);
console.log(`  RESULT: ${passed}/${results.length} patches parsed successfully${failed > 0 ? ` (${failed} failed)` : ""}`);
console.log(`${"═".repeat(80)}\n`);

// Write summary JSON
const summary = { 
  timestamp: new Date().toISOString(), 
  patchCount: results.length,
  passed, failed,
  totals: { champions: totalChamps, items: totalItems, systems: totalSystems, stats: totalStats },
  results 
};
fs.writeFileSync(path.join(__dirname, "harness-results.json"), JSON.stringify(summary, null, 2));
console.log(`Results written to test/harness-results.json`);

process.exit(failed > 0 ? 1 : 0);
