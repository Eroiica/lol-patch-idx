#!/usr/bin/env node
/**
 * Fetch patch notes from Riot's site and save as markdown fixtures.
 * 
 * Usage:
 *   node scripts/fetch-patches.js                 # Fetch all missing patches
 *   node scripts/fetch-patches.js --patch 25.20   # Fetch specific patch
 *   node scripts/fetch-patches.js --list           # List all known patches
 *
 * Requires: Node 18+ (uses native fetch)
 * 
 * NOTE: If running in a restricted network environment, you may need
 * to use the web_fetch approach (see README) to download pages externally
 * and save them as fixtures manually.
 */
const fs = require("fs");
const path = require("path");
const { KNOWN_PATCHES, patchUrl } = require("../src/fetch/patchIndex");

const OUT_DIR = path.join(__dirname, "..", "test", "fixtures", "live");

async function fetchPatch(patchId) {
  const url = patchUrl(patchId);
  console.log(`  Fetching ${url}...`);
  
  const res = await fetch(url, {
    headers: { "User-Agent": "lol-patch-idx/2.0" },
  });
  
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const html = await res.text();
  
  // Extract text content (basic HTML-to-markdown conversion)
  // For production use, install cheerio and use domToBlocks
  return html;
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const args = process.argv.slice(2);
  
  if (args.includes("--list")) {
    for (const [id, slug] of Object.entries(KNOWN_PATCHES)) {
      const fp = path.join(OUT_DIR, `${id}.md`);
      const exists = fs.existsSync(fp);
      console.log(`  ${exists ? "✓" : "○"} ${id.padEnd(6)} ${slug}`);
    }
    return;
  }
  
  let toFetch;
  const patchArg = args.indexOf("--patch");
  if (patchArg !== -1 && args[patchArg + 1]) {
    toFetch = [[args[patchArg + 1], KNOWN_PATCHES[args[patchArg + 1]]]];
  } else {
    toFetch = Object.entries(KNOWN_PATCHES).filter(([id]) => {
      return !fs.existsSync(path.join(OUT_DIR, `${id}.md`));
    });
  }
  
  console.log(`${toFetch.length} patches to fetch\n`);
  
  for (const [id, slug] of toFetch) {
    if (!slug) { console.log(`  Unknown patch: ${id}`); continue; }
    try {
      const content = await fetchPatch(id);
      fs.writeFileSync(path.join(OUT_DIR, `${id}.md`), content);
      console.log(`  ✓ ${id} saved (${content.length} chars)`);
    } catch (err) {
      console.log(`  ✗ ${id} failed: ${err.message}`);
    }
    await new Promise(r => setTimeout(r, 1500));
  }
}

main().catch(console.error);
